const twilio = require('twilio');
const axios = require('axios');
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const feedbackSid = process.env.FEEDBACK_SID;
const deliveredSid = process.env.DELIVERED_SID;
const placedSid = process.env.PLACED_SID;
const serviceId = process.env.TWILIO_MESSAGING_SERVICE_ID;
const message = async (templateId, customerName, productListString, toPhoneNumber) => {
    await client.messages.create({
        contentSid: templateId,
        from: serviceId,
        contentVariables: JSON.stringify({
            1: customerName,
            2: productListString
        }),
        to: 'whatsapp:' + toPhoneNumber
    });
}
const feedbackMessage = async (templateId, customerName, toPhoneNumber) => {
    await client.messages.create({
        contentSid: templateId,
        from: serviceId,
        contentVariables: JSON.stringify({
            1: customerName
        }),
        to: 'whatsapp:' + toPhoneNumber
    });
}
const generateMessage = async (orderStatus, customerName, productListString, toPhoneNumber) => {
    if (orderStatus === "Placed") {
        await message(placedSid, customerName, productListString, toPhoneNumber);
    }
    else {
        await message(deliveredSid, customerName, productListString, toPhoneNumber).then(async () => {
            await feedbackMessage(feedbackSid, customerName, toPhoneNumber);
        })
    }
}

module.exports = { generateMessage };
