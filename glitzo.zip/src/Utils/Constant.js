// First, checks if it isn't implemented yet.
if (!String.prototype.format) {
  String.prototype.format = function () {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function (match, number) {
      return typeof args[number] != 'undefined'
        ? args[number]
        : match;
    });
  };
}

const BASE_PATH = process.env.BASE_PATH || `https://glitzo.loca.lt`;

const greetings = ['hi', 'hello', 'hey', 'holla'];

const maxQuantityLimit = 10;

const catalogue = [
  {
      id: 0,
      media: `${BASE_PATH}/images/set-2-colours.jpg`,
      text: `1️⃣ Organic holi colour- Pack of 2: Rs. 200/-`,
      amount: `200`
  },
  {
      id: 1,
      media: `${BASE_PATH}/images/set-4-colours.jpg`,
      text: `2️⃣ Organic holi colour- Pack of 4: Rs. 500/-`,
      amount: `500`,
  },
  {
      id: 2,
      media: `${BASE_PATH}/images/water-balloons.jpg`,
      text: `3️⃣ Holi balloons- Pack of 3: Rs. 150/-`,
      amount: `150`,
  },
  {
      id: 3,
      media: `${BASE_PATH}/images/snow-spray.jpg`,
      text: `4️⃣ Holi snow spray- Pack of 3: Rs. 200/-`,
      amount: `200`
  },
  {
      id: 4,
      media: `${BASE_PATH}/images/spray-cylinder.jpg`,
      text: `5️⃣ Spray cylinder- 2kg: Rs. 1200/-`,
      amount: `1200`
  }
];
const qrCodeImagePath = `${BASE_PATH}/images/QR.png`;
const data = {
  welcomeMessage: `Hi {0} 🙋🏻‍♀️,\n\nWelcome to Glitzo Store. Please type *Yes* to view catalogue`,
  productNumberMessage: `Please input the product number (1 to 7) one by one to add items to your cart 🛒`,
  productChoiceMessage: `You have chosen *{0}*.\n\nEnter Quantity (Maximum {1}) to add the product to your cart 🛒`,
  nextProductMessage: `Enter Product Number 🔢 of next item to add the product to your cart 🛒 or press 0️⃣ to checkout`,
  thankyouMessage: `Thank you for selecting *Glitzo*! You're welcome to shop with us anytime by using *Hi* or *Hello*.`,
  deliveryAddressMessage: `Before you proceed to checkout, kindly share your complete delivery address, including the PIN code. 📍\n\nTo ensure a smooth transaction, providing your delivery address is crucial.`,
  billingSummaryMessage: `Billing Summary:\n`,
  billingLine1Message: `{0}, Quantity: {1}, Amount: {2}/-\n`,
  billingLine2Message: `\n*Total Amount: {0}/-*\n`,
  billingLine3Message: `To complete your purchase, `,
  billingLine4Message: `use above QR code for easy payment:\n\n`,
  billingLine5Message: `After completing the payment, remember to enter text *Done* and share a screenshot of the transaction or enter 0️⃣ to cancel the order in this chat.`,
  thankyouOrderSuccessMessage: `Thank you for your order ({0})! We're currently processing it. Our team will verify the payment, and your items are expected to be delivered within 5-6 days. If you have any questions or need assistance, feel free to reach out to our support team at +91-9238389357.`,
  initNewMessage: `To start a new order, simply send a greeting like 'Hi' or 'Hello'.`,
  invalidResponse: "Kindly provide a valid text in response.",
  invalidProductResponse: `Please enter a number between 1 and {0}, corresponding to the items listed in the catalogue above.`,
  invalidQuantityResponse: `Quantity should be specified between 1 and {0} for each item in the catalogue.`,
  cancelledMessageResponse: `Your order has been cancelled. To start a new order, simply send a greeting like *Hi* or *Hello*. We're here to assist you with a fresh shopping experience!`,
  somethingWrongMessageResponse: `An unexpected issue has occurred. To initiate a new order, send a greeting such as *Hi* or *Hello*. We're ready to assist you with a new shopping experience!`,
  goBackMessage: `Enter 0️⃣ To Cancel`,

  getWelcomeMessage(profileName) {
    return this.welcomeMessage.format(profileName)
  },
  getProductNumberMessage() {
    return this.productNumberMessage;
  },
  getProductChoiceMessage(productName, maxQuantity) {
    return this.productChoiceMessage.format(productName, maxQuantity)
  },
  getNextProductMessage() {
    return this.nextProductMessage;
  },
  getThankyouMessage() {
    return this.thankyouMessage;
  },
  getDeliveryAddressMessage() {
    return this.deliveryAddressMessage;
  },
  getBillingSummaryMessage() {
    return this.billingSummaryMessage;
  },
  getBillingLine1Message(productName, quantity, totalAmount) {
    return this.billingLine1Message.format(productName, quantity, totalAmount)
  },
  getBillingLine2Message(totalAmount) {
    return this.billingLine2Message.format(totalAmount)
  },
  getBillingLine3Message(totalAmount) {
    return this.billingLine3Message;
  },
  getBillingLine4Message() {
    return this.billingLine4Message;
  },
  getBillingLine5Message() {
    return this.billingLine5Message;
  },
  getThankyouOrderSuccessMessage(orderId) {
    return this.thankyouOrderSuccessMessage.format(orderId)
  },
  getInvalidMessage() {
    return this.invalidResponse;
  },
  getInitNewMessage() {
    return this.initNewMessage;
  },
  getCancelledMessageResponse() {
    return this.cancelledMessageResponse;
  },
  getGoBackMessage() {
    return this.goBackMessage;
  },
  getInvalidProductResponse(itemCount) {
    return this.invalidProductResponse.format(itemCount)
  },
  getInvalidQuantityResponse(itemCount) {
    return this.invalidQuantityResponse.format(itemCount)
  },
  getSomethingWrongMessageResponse() {
    return this.somethingWrongMessageResponse
  }
}

module.exports = { data, greetings, catalogue, qrCodeImagePath, maxQuantityLimit }; // Exporting the constants object
